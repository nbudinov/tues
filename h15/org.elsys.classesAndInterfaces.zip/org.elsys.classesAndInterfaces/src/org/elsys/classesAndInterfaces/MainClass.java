package org.elsys.classesAndInterfaces;

public class MainClass {

	public static void main(String[] args) {

		DirectEvaluatorFactory d = new DirectEvaluatorFactory();
		d.add(4.0);
		d.add(-5.0);

		AbsoluteEvaluatorFactory a = new AbsoluteEvaluatorFactory();
		a.add(4.0);
		a.add(-5.0);

		IEvaluator sumDirect = d.createSumEvaluator();
		System.out.println(sumDirect.evaluate());

		IEvaluator sumAbsolute = a.createSumEvaluator();
		System.out.println(sumAbsolute.evaluate());

		IEvaluator powDirect = d.createPowerOnEvaluator();
		System.out.println(powDirect.evaluate());

		IEvaluator powAbsolute = a.createPowerOnEvaluator();
		System.out.println(powAbsolute.evaluate());

		IEvaluator powD2 = d.createPowerOnEvaluator(2);
		System.out.println(powD2.evaluate());

		IEvaluator powA2 = a.createPowerOnEvaluator(3);
		System.out.println(powA2.evaluate());
	}

}
