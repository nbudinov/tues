package org.elsys.classesAndInterfaces;

import java.util.ArrayList;
import java.util.List;

public class Evaluator implements IEvaluator{

	List<Double> eval = new ArrayList<Double>();
	Double result = 0.0;
	
	public void add(Double d){
		eval.add(d);
	}
	
	public Double evaluate(){
		return result;
	}

}
