package org.elsys.classesAndInterfaces;

public interface IEvaluator {

	void add(Double d);

	Double evaluate();
}
