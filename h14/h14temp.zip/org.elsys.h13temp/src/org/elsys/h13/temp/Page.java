package org.elsys.h13.temp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Page {
	String content = null;
	String url;
	String[] link = new String[100000];

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		try {
			URL google = new URL(url);
			URLConnection yc = google.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					yc.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				content += inputLine;

			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String[] getLink() {
		Pattern linkPattern = Pattern.compile(
				"\\s*(?i)href\\s*=\\s*(\"([^\"]*\")|'[^']*'|([^'\">\\s]+))",
				Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		try {
			URL google = new URL(url);
			URLConnection yc = google.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					yc.getInputStream()));
			String inputLine;
			int i = 0;
			while ((inputLine = in.readLine()) != null) {
				if (inputLine.toLowerCase().contains("a href=".toLowerCase())) {
					link[i] = inputLine;
					Matcher pageMatcher = linkPattern.matcher(link[i]);
					while (pageMatcher.find()) {
						String newLink = pageMatcher.group(1).replaceAll("\"",
								"");
						;
						System.out.println(newLink);
						// System.out.println(pageMatcher.group(1));
					}
					i++;
				}
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return link;
	}

	public void setLink(String[] link) {
		this.link = link;
	}

}