package org.elsys.h13.temp;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Site webSite = new Site();
		Page webPage = new Page();
		Link webLink = new Link();

		Scanner userInput = new Scanner(System.in);
		String webSiteUrl;
		webSiteUrl = userInput.next();
		webSite.setUrl(webSiteUrl);
		webPage.setUrl(webSiteUrl);
		webLink.setValue(webSiteUrl);
		userInput.close();

		webPage.getLink();
		webPage.getContent();
		webSite.getPages();
		webLink.download();
	}
}