package balls_and_boxes;

public class balls_and_boxes_main {

	public static void main(String[] args) {

		BallContainer bc = new BallContainer(6);
		Ball b1 = new Ball();
		Ball b2 = new Ball();

		bc.add(b1);
		bc.add(b2);
		bc.add(b2);
		System.out.println(bc.isSize());
		bc.remove(b2);
		bc.remove(b2);
		System.out.println(bc.isSize());
		System.out.println(bc.contains(b2));
		bc.add(b2);
		System.out.println(bc.contains(b2));
		System.out.println(bc.getCapacity());
		bc.clear();
		System.out.println(bc.isSize());
	}
}
