package balls_and_boxes;

public class Ball {

}
