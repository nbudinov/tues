package balls_and_boxes;

import java.util.ArrayList;

public class BallContainer {
	ArrayList<Ball> BallContainer = new ArrayList<Ball>();
	int size;

	BallContainer(int i) {
		size = i;
		BallContainer = new ArrayList<Ball>(size);
	}

	void add(Ball b) {
		if ((BallContainer.contains(b)) || (BallContainer.size() == size)) {
			System.out.println("Already in or container's full");
		} else {
			BallContainer.add(b);
		}
	}

	void remove(Ball b) {
		if (BallContainer.contains(b)) {
			BallContainer.remove(b);
		} else {
			System.out.println("Doesn't exist");
		}
	}

	int isSize() {
		return BallContainer.size();
	}

	boolean contains(Ball b) {
		return BallContainer.contains(b);
	}

	int getCapacity() {
		return (size - BallContainer.size());
	}

	void clear() {
		BallContainer.clear();
	}

}