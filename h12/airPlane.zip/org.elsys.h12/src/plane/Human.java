package plane;

public class Human {

	private String name;
	private String gender;

	Human(String s1, String s2) {
		name = s1;
		gender = s2;
	}

	void setName(String s1) {
		name = s1;
	}

	void setGender(String s2) {
		gender = s2;
	}

	String getName() {
		return name;
	}

	String getGender() {
		return gender;
	}
}
