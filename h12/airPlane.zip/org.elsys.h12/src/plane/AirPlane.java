package plane;

public class AirPlane {

	public static void main(String[] args) {
		Plane airPlane = new Plane();
		Human h1 = new Human(" Taco ", "M");
		Human h2 = new Human(" Rico ", "M");
		Human h3 = new Human(" Sico ", "F");
		Human h4 = new Human(" Rique ", "Unknown");
		Human h5 = new Human(" Muhito ", "M");
		Human h6 = new Human(" Dang ", "F");
		Human h7 = new Human(" Sica ", "F");
		Human h8 = new Human(" Erique ", "Unknown");
		Human h9 = new Human(" O'Neil ", "F");

		airPlane.fill();

		airPlane.printSeats();
		System.out.println("*******");

		airPlane.add(h1);
		airPlane.add(h2,h3);
		airPlane.add(h4,h5,h6);
		airPlane.add(h7);
		airPlane.add(h8);
		airPlane.add(h9);

		airPlane.printSeats();
		System.out.println("*******");

		System.out.println("Number of Males: " + airPlane.getMales());
		System.out.println("Number of Females: " + airPlane.getFemales());
		System.out.println("*******");

		airPlane.remove(h5);
		airPlane.remove(h2);

		airPlane.printSeats();
		System.out.println("*******");

		System.out.println("Capacity is: " + airPlane.getCapacity());
		System.out.println("*******");

		airPlane.clear();
		airPlane.printSeats();
	}
}