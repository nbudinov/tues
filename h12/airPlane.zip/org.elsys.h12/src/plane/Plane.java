package plane;

public class Plane {

	private String[][] passengers = new String[6][27];
	private int row = 0;
	private int col = 0;
	private boolean emp;
	private int size = 0;
	private String[] genders = new String[162];
	private int i = 0;

	public void fill() {
		for (int row = 0; row < 27; row++) {
			for (int col = 0; col < 6; col++) {
				passengers[col][row] = " null ";
			}
		}
	}

	public void add(Human h1) {
		String humanName = h1.getName();
		String humanGender = h1.getGender();
		emp = false;
		while (emp != true) {
			if (passengers[col][row] == " null ") {
				passengers[col][row] = humanName;
				col += 1;
				emp = true;
				if (col == 6) {
					col = 0;
					row++;
				}
			} else {
				col++;
				if (col == 6) {
					row++;
				}
			}
		}
		genders[i] = humanGender;
		i++;
	}

	public void add(Human h1, Human h2) {
		String humanName1 = h1.getName();
		String humanGender1 = h1.getGender();
		String humanName2 = h2.getName();
		String humanGender2 = h2.getGender();
		emp = false;
		while (emp != true) {
			if (col == 0 || col == 1 || col == 3 || col == 4){
				if (passengers[col][row] == " null ") {
					passengers[col][row] = humanName1;
					passengers[col+1][row] = humanName2;
					col += 2;
					emp = true;
					if (col == 6) {
						col = 0;
						row++;
					}
				} else {
					col++;
					if (col == 6) {
						row++;
					}
				}
			} else if (row != 27){
				row++;
			} else emp=true;
		}
	
		genders[i] = humanGender1;
		i++;
		genders[i] = humanGender2;
		i++;
	}
	
	public void add(Human h1, Human h2, Human h3) {
		String humanName1 = h1.getName();
		String humanGender1 = h1.getGender();
		String humanName2 = h2.getName();
		String humanGender2 = h2.getGender();
		String humanName3 = h3.getName();
		String humanGender3 = h3.getGender();
		emp = false;
		while (emp != true) {
			if (col == 0 || col == 3) {
				if (passengers[col][row] == " null ") {
					passengers[col][row] = humanName1;
					passengers[col + 1][row] = humanName2;
					passengers[col + 2][row] = humanName3;
					col += 3;
					emp = true;
					if (col == 6) {
						col = 0;
						row++;
					}
				} else {
					col++;
					if (col == 6) {
						row++;
					}
				}
			} else if (row != 27) {
				row++;
			} else
				emp = true;
		}

		genders[i] = humanGender1;
		i++;
		genders[i] = humanGender2;
		i++;
		genders[i] = humanGender3;
		i++;
	}

	public void printSeats() {
		for (int row = 0; row < 27; row++) {
			for (int col = 0; col < 6; col++) {
				System.out.print(passengers[col][row]);
				if (col == 2)
					System.out.print("  ");
			}
			System.out.println("");
		}
	}

	public void remove(Human h) {
		String humanName = h.getName();
		for (int row = 0; row < 27; row++) {
			for (int col = 0; col < 6; col++) {
				if (passengers[col][row] == humanName) {
					passengers[col][row] = " null ";
				}
			}
		}
	}

	public void clear() {
		for (int row = 0; row < 27; row++) {
			for (int col = 0; col < 6; col++) {
				passengers[col][row] = null;
			}
		}
	}

	public int getCapacity() {
		for (int row = 0; row < 27; row++) {
			for (int col = 0; col < 6; col++) {
				if (passengers[col][row] != " null ") {
					size++;
				}
			}
		}
		return 162 - size;
	}

	public int getMales() {
		int count = 0;
		for (i = 0; i < 162; i++) {
			if (genders[i] == "M") {
				count++;
			}
		}
		return count;
	}

	public int getFemales() {
		int count = 0;
		for (i = 0; i < 162; i++) {
			if (genders[i] == "F") {
				count++;
			}
		}
		return count;
	}
}